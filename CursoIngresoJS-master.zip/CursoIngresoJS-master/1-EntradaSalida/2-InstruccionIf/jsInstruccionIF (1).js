function mostrar()
{   var edad;
    edad = parseInt(document.getElementById("edad").value);
    if(edad == 15)
    {alert("Niña bonita");}
alert("sarasa")}