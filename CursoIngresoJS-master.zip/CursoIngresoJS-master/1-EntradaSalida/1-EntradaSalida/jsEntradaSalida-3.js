<<<<<<< HEAD
/*Debemos lograr tomar un dato por 'ID'
y luego mostrarlo por 'Alert' al presionar el botón  'mostrar'*/
function mostrar() {
    var nombre;

    nombre = document.getElementById("elNombre").value;

    alert(nombre);

}


=======
/*Debemos lograr tomar un dato por 'ID'
y luego mostrarlo por 'Alert' al presionar el botón  'mostrar'*/
function mostrar() {
    var nombre;

    nombre = document.getElementById("elNombre").value;

    alert(nombre);

}


>>>>>>> d5b7be0e27d131e9549403d35bd44fd74a921994
