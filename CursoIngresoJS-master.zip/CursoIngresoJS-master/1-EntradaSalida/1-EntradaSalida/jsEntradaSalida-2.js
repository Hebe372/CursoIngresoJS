<<<<<<< HEAD
/*Debemos lograr tomar un nombre con 'prompt' 
y luego mostrarlo por 'alert' al presionar el botón  'mostrar'*/
function mostrar() {

    
  var nombre;

  nombre = prompt("Ingrese su nombre");

  alert(nombre);


}

=======
/*Debemos lograr tomar un nombre con 'prompt' 
y luego mostrarlo por 'alert' al presionar el botón  'mostrar'*/
function mostrar() {

    
  var nombre;

  nombre = prompt("Ingrese su nombre");

  alert(nombre);


}

>>>>>>> d5b7be0e27d131e9549403d35bd44fd74a921994
