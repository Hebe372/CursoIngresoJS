<<<<<<< HEAD
//Debemos lograr mostrar un mensaje al presionar el botón  'mostrar'.
function mostrar()
{

    alert("Esto funciona de maravilla");
	
}

=======
//Debemos lograr mostrar un mensaje al presionar el botón  'mostrar'.
function mostrar()
{

    alert("Esto funciona de maravilla");
	
}

>>>>>>> d5b7be0e27d131e9549403d35bd44fd74a921994
