<<<<<<< HEAD
/* 
	Debemos lograr tomar un dato por 'PROMPT' 
	y lo muestro por 'getElementById' al presionar el botón 'mostrar'
*/
function mostrar()
{
	var nombres;

	nombre = prompt("Ingrese su nombre por favor");

    document.getElementById("elNombre").value = nombre;

}

=======
/* 
	Debemos lograr tomar un dato por 'PROMPT' 
	y lo muestro por 'getElementById' al presionar el botón 'mostrar'
*/
function mostrar()
{
	var nombre;

	nombre = prompt("Ingrese su nombre");

    document.getElementById("elNombre").value = nombre;

}

>>>>>>> d5b7be0e27d131e9549403d35bd44fd74a921994
